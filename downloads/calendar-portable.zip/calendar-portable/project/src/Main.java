import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

public class Main {
    private static final String VIEW_ALL = "통합";
    private static final String VIEW_CALENDAR = "달력";
    private static final String VIEW_SCHEDULE = "일정";
    private static final String VIEW_BUDGET = "가계부";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::createAndShowUi);
    }

    private static void createAndShowUi() {
        AppState state = new AppState();
        state.load();

        JFrame frame = new JFrame("일정 및 가계부");
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        JPanel root = new StyleUtil.GradientPanel();
        root.setLayout(new BorderLayout(0, 8));

        JPanel topBar = buildTopBar(state);
        root.add(topBar, BorderLayout.NORTH);

        JPanel calendarSection = createCalendarSection(state);
        JPanel scheduleSection = SchedulePanel.create(state, () -> refreshAll(state));
        JPanel budgetSection = BudgetPanel.create(state, () -> refreshAll(state));

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(0, 16, 16, 16));
        content.add(calendarSection);
        content.add(Box.createVerticalStrut(10));
        content.add(scheduleSection);
        content.add(Box.createVerticalStrut(10));
        content.add(budgetSection);

        JComboBox<String> viewCombo = new JComboBox<>(new String[] {VIEW_ALL, VIEW_CALENDAR, VIEW_SCHEDULE, VIEW_BUDGET});
        viewCombo.setFont(StyleUtil.BODY_FONT);
        viewCombo.setBorder(BorderFactory.createLineBorder(StyleUtil.PURPLE_LINE));
        viewCombo.addActionListener(e -> {
            String view = String.valueOf(viewCombo.getSelectedItem());
            calendarSection.setVisible(VIEW_ALL.equals(view) || VIEW_CALENDAR.equals(view));
            scheduleSection.setVisible(VIEW_ALL.equals(view) || VIEW_SCHEDULE.equals(view));
            budgetSection.setVisible(VIEW_ALL.equals(view) || VIEW_BUDGET.equals(view));
            content.revalidate();
            content.repaint();
        });

        JPanel viewPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        viewPanel.setOpaque(false);
        viewPanel.add(StyleUtil.makeLabel("보기"));
        viewPanel.add(viewCombo);
        topBar.add(viewPanel, BorderLayout.EAST);

        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        root.add(scrollPane, BorderLayout.CENTER);

        frame.setContentPane(root);
        frame.setSize(1140, 940);
        frame.setMinimumSize(new Dimension(360, 640));
        frame.setLocationRelativeTo(null);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                state.save();
                state.saveBackup();
                frame.dispose();
                System.exit(0);
            }
        });
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                applyResponsiveLayout(state, frame.getWidth());
            }
        });
        frame.setVisible(true);

        refreshAll(state);
        applyResponsiveLayout(state, frame.getWidth());
    }

    private static JPanel buildTopBar(AppState state) {
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.setBorder(BorderFactory.createEmptyBorder(14, 16, 8, 16));

        JLabel title = new JLabel("일정 & 가계부 다이어리");
        title.setFont(StyleUtil.TITLE_FONT);
        title.setForeground(StyleUtil.PURPLE_MAIN);

        state.selectedDateLabel = new JLabel("선택 날짜: 없음");
        state.selectedDateLabel.setFont(StyleUtil.BODY_FONT);
        state.selectedDateLabel.setForeground(StyleUtil.TEXT_SOFT);

        javax.swing.JButton clearDate = new javax.swing.JButton("날짜 선택 해제");
        StyleUtil.styleButton(clearDate, false);
        clearDate.addActionListener(e -> {
            clearSelectedDateFilter(state);
            refreshAll(state);
        });

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.add(title);
        left.add(state.selectedDateLabel);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setOpaque(false);
        right.add(clearDate);

        top.add(left, BorderLayout.WEST);
        top.add(right, BorderLayout.EAST);
        return top;
    }

    private static JPanel createCalendarSection(AppState state) {
        StyleUtil.CardPanel card = new StyleUtil.CardPanel();
        card.setLayout(new BorderLayout(8, 8));
        card.add(StyleUtil.sectionTitle("달력"), BorderLayout.NORTH);

        javax.swing.JSpinner yearSpinner = new javax.swing.JSpinner(state.calendarYearModel);
        javax.swing.JSpinner monthSpinner = new javax.swing.JSpinner(state.calendarMonthModel);

        state.calendarPanel = new CalendarPanel(
            () -> state.scheduleItems,
            () -> state.budgetItems,
            date -> syncSelectedDate(state, date)
        );

        Runnable onCalendarChanged = FilterUtil.createFilterListener(state, () -> {
            state.calendarPanel.setYearMonth(state.calendarYearModel.getNumber().intValue(), state.calendarMonthModel.getNumber().intValue());
            refreshAll(state);
        });
        FilterUtil.setupFilterListeners(yearSpinner, monthSpinner, onCalendarChanged);

        state.calendarPanel.setYearMonth(state.calendarYearModel.getNumber().intValue(), state.calendarMonthModel.getNumber().intValue());

        JPanel control = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        control.setOpaque(false);
        control.add(StyleUtil.makeLabel("연도"));
        control.add(yearSpinner);
        control.add(StyleUtil.makeLabel("월"));
        control.add(monthSpinner);

        JPanel body = new JPanel(new BorderLayout(8, 8));
        body.setOpaque(false);
        body.add(control, BorderLayout.NORTH);
        body.add(state.calendarPanel, BorderLayout.CENTER);

        card.add(body, BorderLayout.CENTER);
        return card;
    }

    static void refreshAll(AppState state) {
        refreshScheduleTable(state);
        refreshBudgetTable(state);
        refreshBudgetSummary(state);
        refreshBudgetStats(state);
        if (state.calendarPanel != null) {
            state.calendarPanel.repaint();
        }
    }

    private static void refreshScheduleTable(AppState state) {
        state.visibleSchedules = FilterUtil.filterSchedules(
            state.scheduleItems,
            state.scheduleYearModel.getNumber().intValue(),
            state.scheduleMonthModel.getNumber().intValue(),
            state.selectedDate
        );

        state.visibleSchedules.sort(Comparator.comparing(ScheduleItem::getDate));

        state.scheduleModel.setRowCount(0);
        for (ScheduleItem item : state.visibleSchedules) {
            state.scheduleModel.addRow(new Object[] {item.getDate().toString(), item.getTitle(), item.getMemo()});
        }
    }

    private static void refreshBudgetTable(AppState state) {
        List<BudgetItem> filtered = FilterUtil.filterBudgets(
            state.budgetItems,
            state.budgetYearModel.getNumber().intValue(),
            state.budgetMonthModel.getNumber().intValue(),
            state.selectedDate
        );

        filtered.sort(
            Comparator.comparing(BudgetItem::getDate)
                .thenComparing(BudgetItem::getCategory, String.CASE_INSENSITIVE_ORDER)
                .thenComparingLong(BudgetItem::getAmount)
        );

        state.visibleBudgets = new ArrayList<>(filtered);

        state.budgetModel.setRowCount(0);
        for (BudgetItem item : state.visibleBudgets) {
            state.budgetModel.addRow(new Object[] {
                item.getDate().toString(),
                item.getType(),
                item.getCategory(),
                String.format(Locale.KOREA, "%,d", item.getAmount()),
                item.getMemo(),
                item.getPhotoPath()
            });
        }
    }

    private static void refreshBudgetStats(AppState state) {
        if (state.budgetStatsPanel == null) return;
        String title = (state.selectedDate != null)
            ? state.selectedDate + " 통계"
            : String.format("%d-%02d 통계", state.budgetYearModel.getNumber().intValue(), state.budgetMonthModel.getNumber().intValue());
        state.budgetStatsPanel.setData(state.visibleBudgets, title);
    }

    private static void refreshBudgetSummary(AppState state) {
        long in = 0;
        long out = 0;
        for (BudgetItem item : state.visibleBudgets) {
            if (AppState.TYPE_INCOME.equals(item.getType())) {
                in += item.getAmount();
            } else {
                out += item.getAmount();
            }
        }
        state.totalInLabel.setText("총입금: " + formatCurrency(in));
        state.totalOutLabel.setText("총출금: " + formatCurrency(out));
        state.totalNetLabel.setText("총액: " + formatCurrency(in - out));
    }

    static void syncSelectedDate(AppState state, LocalDate date) {
        state.selectedDate = date;
        state.selectedDateLabel.setText("선택 날짜: " + date);

        state.scheduleYearModel.setValue(date.getYear());
        state.scheduleMonthModel.setValue(date.getMonthValue());
        state.budgetYearModel.setValue(date.getYear());
        state.budgetMonthModel.setValue(date.getMonthValue());
        state.calendarYearModel.setValue(date.getYear());
        state.calendarMonthModel.setValue(date.getMonthValue());

        if (state.scheduleDateField != null) state.scheduleDateField.setText(date.toString());
        if (state.budgetDateField != null) state.budgetDateField.setText(date.toString());

        refreshAll(state);
    }

    private static void clearSelectedDateFilter(AppState state) {
        state.selectedDate = null;
        if (state.selectedDateLabel != null) state.selectedDateLabel.setText("선택 날짜: 없음");
        if (state.calendarPanel != null) state.calendarPanel.clearSelectedDate();
    }

    static void applyResponsiveLayout(AppState state, int width) {
        boolean compact = width < 860;
        if (state.compactMode == compact) return;
        state.compactMode = compact;

        if (state.calendarPanel != null) state.calendarPanel.setCompactMode(compact);

        if (state.budgetWrap != null && state.budgetCategoryPanel != null) {
            state.budgetWrap.remove(state.budgetCategoryPanel);
            state.budgetWrap.add(state.budgetCategoryPanel, compact ? BorderLayout.SOUTH : BorderLayout.EAST);
            state.budgetCategoryPanel.setPreferredSize(compact ? null : new Dimension(220, 180));

            if (state.budgetCategoryList != null) {
                if (compact) {
                    state.budgetCategoryList.setLayoutOrientation(JList.HORIZONTAL_WRAP);
                    state.budgetCategoryList.setVisibleRowCount(1);
                } else {
                    state.budgetCategoryList.setLayoutOrientation(JList.VERTICAL);
                    state.budgetCategoryList.setVisibleRowCount(4);
                }
            }
            if (state.budgetCategoryScroll != null) {
                state.budgetCategoryScroll.setPreferredSize(compact ? new Dimension(0, 64) : new Dimension(200, 112));
            }

            state.budgetWrap.revalidate();
            state.budgetWrap.repaint();
        }
    }

    static boolean isValidDate(String value) {
        try {
            LocalDate.parse(value);
            return true;
        } catch (DateTimeParseException ex) {
            return false;
        }
    }

    static void showError(String message) {
        JOptionPane.showMessageDialog(null, message, "입력 오류", JOptionPane.ERROR_MESSAGE);
    }

    static String formatCurrency(long value) {
        return String.format(Locale.KOREA, "%,d원", value);
    }
}