import java.time.LocalDate;

public class ScheduleItem {
    private final LocalDate date;
    private final String title;
    private final String memo;

    public ScheduleItem(LocalDate date, String title, String memo) {
        this.date = date;
        this.title = title;
        this.memo = memo;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getTitle() {
        return title;
    }

    public String getMemo() {
        return memo;
    }
}