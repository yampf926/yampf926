import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class BudgetPanel {
    private static final Map<String, ImageIcon> THUMB_CACHE = new HashMap<>();

    private BudgetPanel() {}

    public static JPanel create(AppState state, Runnable refreshAll) {
        StyleUtil.CardPanel card = new StyleUtil.CardPanel();
        card.setLayout(new BorderLayout(8, 8));
        card.add(StyleUtil.sectionTitle("가계부"), BorderLayout.NORTH);

        state.budgetModel = new DefaultTableModel(new Object[] {
            "날짜", "구분", "카테고리", "금액", "메모", "사진"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = StyleUtil.createStyledTable(state.budgetModel);
        StyleUtil.styleBudgetMemoRenderer(table);
        installPhotoRenderer(table);
        table.setRowHeight(38);

        JTextField dateField = new JTextField(LocalDate.now().toString(), 11);
        state.budgetDateField = dateField;
        JComboBox<String> typeCombo = new JComboBox<>(new String[] {AppState.TYPE_EXPENSE, AppState.TYPE_INCOME});

        DefaultComboBoxModel<String> categoryComboModel = new DefaultComboBoxModel<>();
        DefaultListModel<String> categoryListModel = new DefaultListModel<>();
        String[] defaults = {
            "식비", "교통", "쇼핑", "생활", "공과금", "취미", "기타"
        };
        for (String c : defaults) {
            categoryComboModel.addElement(c);
            categoryListModel.addElement(c);
        }

        JComboBox<String> categoryCombo = new JComboBox<>(categoryComboModel);
        JList<String> categoryList = new JList<>(categoryListModel);
        categoryList.setFont(StyleUtil.BODY_FONT);

        JTextField amountField = new JTextField(8);
        JTextField memoField = new JTextField(12);
        JTextField newCategoryField = new JTextField(10);
        StyleUtil.styleField(dateField);
        StyleUtil.styleField(amountField);
        StyleUtil.styleField(memoField);
        StyleUtil.styleField(newCategoryField);

        JLabel photoLabel = StyleUtil.makeLabel("사진 없음");
        final String[] attachedPhoto = {""};

        JSpinner filterYear = new JSpinner(state.budgetYearModel);
        JSpinner filterMonth = new JSpinner(state.budgetMonthModel);
        Runnable onFilterChanged = FilterUtil.createFilterListener(state, refreshAll);
        FilterUtil.setupFilterListeners(filterYear, filterMonth, onFilterChanged);

        JButton attachPhotoBtn = new JButton("사진 첨부");
        StyleUtil.styleButton(attachPhotoBtn, false);
        attachPhotoBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                attachedPhoto[0] = file.getAbsolutePath();
                photoLabel.setText(file.getName());
            }
        });

        JButton add = new JButton("추가");
        JButton del = new JButton("삭제");
        JButton addCategory = new JButton("카테고리 추가");
        JButton upCategory = new JButton("위");
        JButton downCategory = new JButton("아래");
        JButton deleteCategory = new JButton("삭제");
        StyleUtil.styleButton(add, true);
        StyleUtil.styleButton(del, false);
        StyleUtil.styleButton(addCategory, false);
        StyleUtil.styleButton(upCategory, false);
        StyleUtil.styleButton(downCategory, false);
        StyleUtil.styleButton(deleteCategory, false);

        state.totalInLabel = StyleUtil.summaryLabel("총입금: 0원");
        state.totalOutLabel = StyleUtil.summaryLabel("총출금: 0원");
        state.totalNetLabel = StyleUtil.summaryLabel("총액: 0원");

        Runnable syncCategoryCombo = () -> {
            categoryComboModel.removeAllElements();
            for (int i = 0; i < categoryListModel.size(); i++) {
                categoryComboModel.addElement(categoryListModel.get(i));
            }
            if (categoryComboModel.getSize() > 0) {
                categoryCombo.setSelectedIndex(0);
            }
        };

        addCategory.addActionListener(e -> {
            String name = newCategoryField.getText().trim();
            if (name.isEmpty()) {
                Main.showError("카테고리 이름을 입력하세요.");
                return;
            }
            for (int i = 0; i < categoryListModel.size(); i++) {
                if (name.equalsIgnoreCase(categoryListModel.get(i))) {
                    categoryList.setSelectedIndex(i);
                    newCategoryField.setText("");
                    return;
                }
            }
            categoryListModel.addElement(name);
            syncCategoryCombo.run();
            categoryCombo.setSelectedItem(name);
            categoryList.setSelectedValue(name, true);
            newCategoryField.setText("");
        });

        upCategory.addActionListener(e -> moveCategory(categoryList, categoryListModel, categoryCombo, syncCategoryCombo, -1));
        downCategory.addActionListener(e -> moveCategory(categoryList, categoryListModel, categoryCombo, syncCategoryCombo, 1));
        deleteCategory.addActionListener(e -> {
            int idx = categoryList.getSelectedIndex();
            if (idx < 0) {
                Main.showError("삭제할 카테고리를 선택하세요.");
                return;
            }
            if (categoryListModel.size() == 1) {
                Main.showError("카테고리는 최소 1개 필요합니다.");
                return;
            }
            categoryListModel.remove(idx);
            syncCategoryCombo.run();
            categoryList.setSelectedIndex(Math.max(0, idx - 1));
        });

        add.addActionListener(e -> {
            BudgetItem created = buildItem(
                dateField.getText().trim(),
                String.valueOf(typeCombo.getSelectedItem()),
                categoryCombo.getSelectedItem() == null ? "" : String.valueOf(categoryCombo.getSelectedItem()),
                amountField.getText().trim(),
                memoField.getText().trim(),
                attachedPhoto[0]
            );
            if (created == null) {
                return;
            }

            state.budgetItems.add(created);
            amountField.setText("");
            memoField.setText("");
            attachedPhoto[0] = "";
            photoLabel.setText("사진 없음");
            state.save();
            refreshAll.run();
        });

        del.addActionListener(e -> deleteSelected(state, table, refreshAll));

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int viewCol = table.columnAtPoint(e.getPoint());
                    int viewRow = table.rowAtPoint(e.getPoint());
                    if (viewCol == 5 && viewRow >= 0 && viewRow < state.visibleBudgets.size()) {
                        showPhotoPreview(table, state.visibleBudgets.get(viewRow).getPhotoPath());
                    } else {
                        editSelected(state, table, refreshAll, categoryComboModel, categoryListModel);
                    }
                }
            }
        });

        JPanel form = StyleUtil.createFormPanel();
        GridBagConstraints gc = StyleUtil.createFormConstraints();

        addCommonFormFields(form, gc, dateField, typeCombo, categoryCombo, amountField, memoField);

        JPanel photoRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        photoRow.setOpaque(false);
        photoRow.add(attachPhotoBtn);
        photoRow.add(photoLabel);
        gc.gridx = 1; gc.gridy = 5; form.add(photoRow, gc);

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        actionRow.setOpaque(false);
        actionRow.add(add);
        actionRow.add(del);
        StyleUtil.addActionRow(form, gc, actionRow, 6);

        JPanel filterRow = StyleUtil.createFilterRow(
            StyleUtil.makeLabel("조회 연도"), filterYear,
            StyleUtil.makeLabel("조회 월"), filterMonth
        );
        StyleUtil.addFilterRow(form, gc, filterRow, 7);

        JPanel summary = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        summary.setOpaque(false);
        summary.add(state.totalInLabel);
        summary.add(state.totalOutLabel);
        summary.add(state.totalNetLabel);

        state.budgetStatsPanel = new BudgetStatsPanel();

        JPanel categoryPanel = new JPanel(new BorderLayout(6, 6));
        categoryPanel.setOpaque(false);
        categoryPanel.setBorder(javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createLineBorder(StyleUtil.PURPLE_LINE),
            javax.swing.BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        categoryPanel.add(StyleUtil.makeLabel("카테고리"), BorderLayout.NORTH);

        categoryList.setVisibleRowCount(4);
        categoryList.setLayoutOrientation(JList.VERTICAL);
        JScrollPane catScroll = new JScrollPane(categoryList);
        catScroll.setPreferredSize(new Dimension(200, 112));
        StyleUtil.styleScroll(catScroll);

        addCategory.setPreferredSize(new Dimension(92, 34));
        JPanel inputRow = new JPanel(new BorderLayout(6, 0));
        inputRow.setOpaque(false);
        inputRow.add(newCategoryField, BorderLayout.CENTER);
        inputRow.add(addCategory, BorderLayout.EAST);

        JPanel actionRowCat = new JPanel(new GridLayout(1, 3, 6, 0));
        actionRowCat.setOpaque(false);
        actionRowCat.add(upCategory);
        actionRowCat.add(downCategory);
        actionRowCat.add(deleteCategory);

        JPanel categoryBody = new JPanel(new GridBagLayout());
        categoryBody.setOpaque(false);
        GridBagConstraints cc = new GridBagConstraints();
        cc.insets = new Insets(0, 0, 6, 0);
        cc.gridx = 0; cc.gridy = 0; cc.weightx = 1; cc.fill = GridBagConstraints.HORIZONTAL; categoryBody.add(inputRow, cc);
        cc.gridy = 1; cc.weighty = 1; cc.fill = GridBagConstraints.BOTH; categoryBody.add(catScroll, cc);
        cc.gridy = 2; cc.weighty = 0; cc.fill = GridBagConstraints.HORIZONTAL; categoryBody.add(actionRowCat, cc);
        categoryPanel.add(categoryBody, BorderLayout.CENTER);

        JScrollPane tableScroll = StyleUtil.createTableScroll(table);

        JPanel body = new JPanel(new BorderLayout(8, 8));
        body.setOpaque(false);
        body.add(form, BorderLayout.NORTH);
        body.add(tableScroll, BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout(0, 8));
        footer.setOpaque(false);
        footer.add(summary, BorderLayout.NORTH);
        footer.add(state.budgetStatsPanel, BorderLayout.CENTER);
        body.add(footer, BorderLayout.SOUTH);

        JPanel wrap = new JPanel(new BorderLayout(8, 8));
        wrap.setOpaque(false);
        wrap.add(body, BorderLayout.CENTER);
        wrap.add(categoryPanel, BorderLayout.EAST);

        state.budgetWrap = wrap;
        state.budgetCategoryPanel = categoryPanel;
        state.budgetCategoryList = categoryList;
        state.budgetCategoryScroll = catScroll;

        card.add(wrap, BorderLayout.CENTER);
        return card;
    }

    private static void addCommonFormFields(JPanel panel, GridBagConstraints gc,
                                            Component dateField, Component typeCombo, Component categoryCombo,
                                            Component amountField, Component memoField) {
        StyleUtil.addFormField(panel, gc, "날짜", dateField, 0);
        StyleUtil.addFormField(panel, gc, "구분", typeCombo, 1);
        StyleUtil.addFormField(panel, gc, "카테고리", categoryCombo, 2);
        StyleUtil.addFormField(panel, gc, "금액", amountField, 3);
        StyleUtil.addFormField(panel, gc, "메모", memoField, 4);
    }

    private static void moveCategory(JList<String> categoryList, DefaultListModel<String> model, JComboBox<String> categoryCombo, Runnable sync, int delta) {
        int idx = categoryList.getSelectedIndex();
        int next = idx + delta;
        if (idx < 0 || next < 0 || next >= model.size()) {
            return;
        }
        String value = model.remove(idx);
        model.add(next, value);
        categoryList.setSelectedIndex(next);
        sync.run();
        categoryCombo.setSelectedItem(value);
    }

    private static void installPhotoRenderer(JTable table) {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object value, boolean selected, boolean focus, int row, int col) {
                JLabel c = (JLabel) super.getTableCellRendererComponent(t, value, selected, focus, row, col);
                c.setHorizontalAlignment(SwingConstants.CENTER);
                c.setIcon(null);
                String path = value == null ? "" : value.toString().trim();
                if (path.isEmpty()) {
                    c.setText("없음");
                    return c;
                }
                ImageIcon icon = resolveThumb(path);
                if (icon != null) {
                    c.setText("");
                    c.setIcon(icon);
                } else {
                    c.setText("파일");
                }
                return c;
            }
        };
        table.getColumnModel().getColumn(5).setCellRenderer(renderer);
    }

    private static ImageIcon resolveThumb(String path) {
        if (!THUMB_CACHE.containsKey(path)) {
            ImageIcon thumb = null;
            File f = new File(path);
            if (f.isFile()) {
                ImageIcon raw = new ImageIcon(path);
                if (raw.getIconWidth() > 0 && raw.getIconHeight() > 0) {
                    Image scaled = raw.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
                    thumb = new ImageIcon(scaled);
                }
            }
            THUMB_CACHE.put(path, thumb);
        }
        return THUMB_CACHE.get(path);
    }

    private static void showPhotoPreview(Component parent, String path) {
        if (path == null || path.trim().isEmpty()) {
            Main.showError("첨부된 사진이 없습니다.");
            return;
        }
        File file = new File(path);
        if (!file.isFile()) {
            Main.showError("이미지 파일을 찾을 수 없습니다.");
            return;
        }
        ImageIcon raw = new ImageIcon(path);
        if (raw.getIconWidth() <= 0 || raw.getIconHeight() <= 0) {
            Main.showError("이미지를 표시할 수 없습니다.");
            return;
        }

        int maxW = 860;
        int maxH = 620;
        double scale = Math.min(1.0, Math.min((double) maxW / raw.getIconWidth(), (double) maxH / raw.getIconHeight()));
        int w = Math.max(1, (int) (raw.getIconWidth() * scale));
        int h = Math.max(1, (int) (raw.getIconHeight() * scale));
        ImageIcon scaled = new ImageIcon(raw.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH));

        JLabel label = new JLabel(scaled);
        JScrollPane pane = new JScrollPane(label);
        pane.setPreferredSize(new Dimension(Math.min(maxW, w + 20), Math.min(maxH, h + 20)));
        JOptionPane.showMessageDialog(parent, pane, "첨부 사진", JOptionPane.PLAIN_MESSAGE);
    }

    private static BudgetItem buildItem(String dateText, String type, String category, String amountText, String memo, String photoPath) {
        if (!Main.isValidDate(dateText)) {
            Main.showError("날짜 형식은 yyyy-MM-dd 입니다.");
            return null;
        }
        if (category == null || category.isEmpty()) {
            Main.showError("카테고리를 선택하세요.");
            return null;
        }

        long amount;
        try {
            amount = Long.parseLong(amountText.replace(",", "").trim());
            if (amount <= 0) {
                Main.showError("금액은 1 이상이어야 합니다.");
                return null;
            }
        } catch (NumberFormatException ex) {
            Main.showError("금액은 숫자로 입력하세요.");
            return null;
        }

        return new BudgetItem(LocalDate.parse(dateText), type, category, amount, memo, photoPath);
    }

    private static void deleteSelected(AppState state, JTable table, Runnable refreshAll) {
        int row = table.getSelectedRow();
        if (row < 0 || row >= state.visibleBudgets.size()) {
            Main.showError("삭제할 내역을 선택하세요.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
            table,
            "선택한 가계부 내역을 삭제할까요?",
            "삭제 확인",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        state.budgetItems.remove(state.visibleBudgets.get(row));
        state.save();
        refreshAll.run();
    }

    private static void editSelected(AppState state, JTable table, Runnable refreshAll, DefaultComboBoxModel<String> categoryComboModel, DefaultListModel<String> categoryListModel) {
        int row = table.getSelectedRow();
        if (row < 0 || row >= state.visibleBudgets.size()) {
            return;
        }

        BudgetItem current = state.visibleBudgets.get(row);

        JTextField dateField = new JTextField(current.getDate().toString(), 12);
        JComboBox<String> typeCombo = new JComboBox<>(new String[] {AppState.TYPE_EXPENSE, AppState.TYPE_INCOME});
        typeCombo.setSelectedItem(current.getType());

        JComboBox<String> categoryCombo = new JComboBox<>();
        for (int i = 0; i < categoryComboModel.getSize(); i++) {
            categoryCombo.addItem(categoryComboModel.getElementAt(i));
        }
        categoryCombo.setSelectedItem(current.getCategory());

        JTextField amountField = new JTextField(String.format(java.util.Locale.KOREA, "%,d", current.getAmount()), 10);
        JTextField memoField = new JTextField(current.getMemo(), 18);
        JTextField photoField = new JTextField(current.getPhotoPath(), 18);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;

        addCommonFormFields(panel, gc, dateField, typeCombo, categoryCombo, amountField, memoField);

        gc.gridx = 0; gc.gridy = 5; gc.weightx = 0; panel.add(StyleUtil.makeLabel("사진경로"), gc);
        gc.gridx = 1; gc.weightx = 1; panel.add(photoField, gc);

        int result = JOptionPane.showConfirmDialog(table, panel, "가계부 수정", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        BudgetItem edited = buildItem(
            dateField.getText().trim(),
            String.valueOf(typeCombo.getSelectedItem()),
            categoryCombo.getSelectedItem() == null ? "" : String.valueOf(categoryCombo.getSelectedItem()),
            amountField.getText().trim(),
            memoField.getText().trim(),
            photoField.getText().trim()
        );
        if (edited == null) {
            return;
        }

        int index = state.budgetItems.indexOf(current);
        if (index >= 0) {
            state.budgetItems.set(index, edited);
            state.save();
            refreshAll.run();
        }

        String category = edited.getCategory();
        boolean found = false;
        for (int i = 0; i < categoryListModel.size(); i++) {
            if (category.equalsIgnoreCase(categoryListModel.get(i))) {
                found = true;
                break;
            }
        }
        if (!found) {
            categoryListModel.addElement(category);
        }
    }
}