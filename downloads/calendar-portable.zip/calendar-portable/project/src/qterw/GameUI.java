package qterw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class GameUI extends JFrame {
    private JTextArea mainArea;
    private JPanel buttonPanel;
    private GameManager manager;

    public GameUI(GameManager manager) {
        this.manager = manager;
        manager.setUI(this);

        setTitle("QTERW - 의식 안정 검사");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.BLACK);

        // 메인 텍스트 영역
        mainArea = new JTextArea();
        mainArea.setEditable(false);
        mainArea.setBackground(Color.BLACK);
        mainArea.setForeground(new Color(200, 200, 200)); // 약간 어두운 흰색
        mainArea.setFont(new Font("Monospaced", Font.PLAIN, 16));
        mainArea.setLineWrap(true);
        mainArea.setWrapStyleWord(true);
        mainArea.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JScrollPane scroll = new JScrollPane(mainArea);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(Color.BLACK);
        add(scroll, BorderLayout.CENTER);

        // 하단 버튼 영역
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(0, 1, 5, 5)); // 세로로 배치
        buttonPanel.setBackground(Color.BLACK);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void clearScreen() {
        mainArea.setText("");
    }

    public void appendText(String text) {
        mainArea.append(text);
        mainArea.setCaretPosition(mainArea.getDocument().getLength());
    }

    public void setOptions(List<String> options) {
        buttonPanel.removeAll();
        
        // 버튼 개수에 따라 그리드 레이아웃 조정 (최대 2열)
        if (options.size() > 4) {
            buttonPanel.setLayout(new GridLayout(0, 2, 10, 10));
        } else {
            buttonPanel.setLayout(new GridLayout(0, 1, 5, 5));
        }

        for (String option : options) {
            JButton btn = new JButton(option);
            btn.setBackground(new Color(30, 30, 30));
            btn.setForeground(Color.WHITE);
            btn.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 100)));
            
            btn.addActionListener(e -> {
                if (option.equals("다시 시도")) {
                    // 간단한 재시작 로직 (실제로는 에피소드 초기화 필요)
                    manager.startEpisode(new Episode1(manager));
                } else if (option.equals("다음 에피소드 (준비중)")) {
                    System.exit(0);
                } else {
                    manager.processInput(option);
                }
            });
            
            buttonPanel.add(btn);
        }
        
        buttonPanel.revalidate();
        buttonPanel.repaint();
    }
}