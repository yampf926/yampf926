package qterw;

import java.util.ArrayList;
import java.util.List;

public class Episode1 extends Episode {
    private boolean incenseOn = true;      // 향이 켜져 있음
    private boolean photoIntact = true;    // 영정사진이 온전함
    private boolean flowerOnAltar = true;  // 국화꽃이 제단에 있음
    private boolean guestBookIntact = true;// 방명록이 온전함
    
    private int timeLeft = 10; // 행동 기회 10번

    public Episode1(GameManager manager) {
        super(manager);
    }

    @Override
    public String getCode() {
        return "Qterw-d-001";
    }

    @Override
    public String getTitle() {
        return "아직 죽지 않은 사람의 장례식";
    }

    @Override
    public void start() {
        manager.print("당신은 장례식장에 서 있습니다.");
        manager.print("검은 양복을 입은 사람들이 보이지 않지만, 곡소리는 들려옵니다.");
        manager.print("정면의 제단을 봅니다.");
        manager.print("영정사진 속 인물은... 당신입니다.");
        manager.print("\n[알림] 입관식까지 시간이 얼마 남지 않았습니다.");
    }

    @Override
    public List<String> getActions() {
        List<String> actions = new ArrayList<>();
        
        if (incenseOn) actions.add("향을 끈다");
        if (photoIntact) actions.add("영정사진을 엎는다");
        if (flowerOnAltar) actions.add("국화꽃을 바닥에 던진다");
        if (guestBookIntact) actions.add("방명록을 찢는다");
        
        actions.add("주변을 둘러본다");
        actions.add("가만히 있는다");
        
        return actions;
    }

    @Override
    public void processAction(String action) {
        timeLeft--;
        
        switch (action) {
            case "향을 끈다":
                incenseOn = false;
                manager.print("향을 손으로 비벼 껐습니다. 매캐한 연기가 사라집니다.");
                manager.print("어디선가 웅성거리는 소리가 작아진 것 같습니다.");
                break;
            case "영정사진을 엎는다":
                photoIntact = false;
                manager.print("자신의 얼굴이 담긴 액자를 바닥에 패대기쳤습니다.");
                manager.print("유리가 깨지는 소리가 유난히 크게 울립니다.");
                break;
            case "국화꽃을 바닥에 던진다":
                flowerOnAltar = false;
                manager.print("가지런히 놓인 하얀 국화를 집어 바닥에 던졌습니다.");
                manager.print("꽃잎이 짓이겨집니다.");
                break;
            case "방명록을 찢는다":
                guestBookIntact = false;
                manager.print("텅 빈 방명록을 집어 북북 찢었습니다.");
                manager.print("종이 조각이 눈처럼 흩날립니다.");
                break;
            case "주변을 둘러본다":
                printStatus();
                break;
            case "가만히 있는다":
                manager.print("아무것도 하지 않았습니다. 시간만 흐릅니다.");
                break;
        }
    }

    private void printStatus() {
        manager.print("=== 현재 상황 ===");
        if (incenseOn) manager.print("- 향이 타오르고 있습니다.");
        if (photoIntact) manager.print("- 영정사진이 당신을 보고 웃고 있습니다.");
        if (flowerOnAltar) manager.print("- 국화꽃이 제단 위에 놓여 있습니다.");
        if (guestBookIntact) manager.print("- 조문객 명단이 비어 있습니다.");
        manager.print("=================");
    }

    @Override
    public void checkStatus() {
        // 모든 조건이 붕괴되었는지 확인
        if (!incenseOn && !photoIntact && !flowerOnAltar && !guestBookIntact) {
            manager.clear("장례 절차가 성립할 수 없습니다.\n당신의 죽음은 '보류'되었습니다.");
            return;
        }

        // 시간 초과 확인
        if (timeLeft <= 0) {
            manager.gameOver("사망 절차 완료 (입관 시간 도래)");
            return;
        }
        
        if (timeLeft <= 3) {
            manager.print("\n[경고] 입관식이 곧 시작됩니다. (" + timeLeft + "턴 남음)");
        }
    }
}