package qterw;

import java.util.List;

public abstract class Episode {
    protected GameManager manager;

    public Episode(GameManager manager) {
        this.manager = manager;
    }

    // 에피소드 ID (예: Qterw-d-001)
    public abstract String getCode();
    
    // 에피소드 제목
    public abstract String getTitle();

    // 게임 시작 시 출력될 텍스트
    public abstract void start();

    // 현재 상황에서 선택 가능한 명령어 목록 반환
    public abstract List<String> getActions();

    // 플레이어의 선택 처리
    public abstract void processAction(String action);
    
    // 상태 업데이트 및 승리/패배 체크
    public abstract void checkStatus();
}