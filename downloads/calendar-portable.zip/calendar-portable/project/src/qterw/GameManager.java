package qterw;

import javax.swing.SwingUtilities;

public class GameManager {
    private GameUI ui;
    private Episode currentEpisode;
    private boolean isGameOver = false;

    public void setUI(GameUI ui) {
        this.ui = ui;
    }

    public void startEpisode(Episode episode) {
        this.currentEpisode = episode;
        this.isGameOver = false;
        ui.clearScreen();
        ui.appendText("========================================\n");
        ui.appendText("기록 코드: " + episode.getCode() + "\n");
        ui.appendText("제 목: " + episode.getTitle() + "\n");
        ui.appendText("========================================\n\n");
        
        // 약간의 딜레이 후 시작
        SwingUtilities.invokeLater(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {}
            episode.start();
            updateOptions();
        });
    }

    public void processInput(String action) {
        if (isGameOver) return;
        
        ui.appendText("\n> " + action + "\n\n");
        currentEpisode.processAction(action);
        currentEpisode.checkStatus();
        
        if (!isGameOver) {
            updateOptions();
        }
    }

    private void updateOptions() {
        ui.setOptions(currentEpisode.getActions());
    }

    public void print(String text) {
        ui.appendText(text + "\n");
    }

    public void gameOver(String reason) {
        isGameOver = true;
        ui.appendText("\n\n[SYSTEM WARNING]\n");
        ui.appendText("개체 재분류 발생.\n");
        ui.appendText("사유: " + reason + "\n");
        ui.appendText("========================================\n");
        ui.appendText("G A M E  O V E R\n");
        ui.setOptions(java.util.List.of("다시 시도"));
    }

    public void clear(String message) {
        isGameOver = true;
        ui.appendText("\n\n[SYSTEM NOTICE]\n");
        ui.appendText("괴담 구조 붕괴 확인.\n");
        ui.appendText("탈출 승인.\n");
        ui.appendText("========================================\n");
        ui.appendText(message + "\n");
        ui.setOptions(java.util.List.of("다음 에피소드 (준비중)"));
    }
}