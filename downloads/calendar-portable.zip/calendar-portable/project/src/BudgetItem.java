import java.time.LocalDate;

public class BudgetItem {
    private final LocalDate date;
    private final String type;
    private final String category;
    private final long amount;
    private final String memo;
    private final String photoPath;

    public BudgetItem(LocalDate date, String type, String category, long amount, String memo, String photoPath) {
        this.date = date;
        this.type = type;
        this.category = category;
        this.amount = amount;
        this.memo = memo;
        this.photoPath = photoPath;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getType() {
        return type;
    }

    public String getCategory() {
        return category;
    }

    public long getAmount() {
        return amount;
    }

    public String getMemo() {
        return memo;
    }

    public String getPhotoPath() {
        return photoPath;
    }
}