import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class CalendarPanel extends JPanel {
    public interface DateSelectListener {
        void onDateSelected(LocalDate date);
    }

    private static final String[] WEEKDAYS = {"일", "월", "화", "수", "목", "금", "토"};
    private static final DecimalFormat BUDGET_DECIMAL = new DecimalFormat("0.###");

    private final Supplier<List<ScheduleItem>> scheduleProvider;
    private final Supplier<List<BudgetItem>> budgetProvider;
    private final DateSelectListener dateSelectListener;

    private int year = LocalDate.now().getYear();
    private int month = LocalDate.now().getMonthValue();
    private LocalDate selectedDate;
    private boolean compactMode;

    public CalendarPanel(Supplier<List<ScheduleItem>> scheduleProvider, Supplier<List<BudgetItem>> budgetProvider, DateSelectListener dateSelectListener) {
        this.scheduleProvider = scheduleProvider;
        this.budgetProvider = budgetProvider;
        this.dateSelectListener = dateSelectListener;

        setPreferredSize(new Dimension(320, 340));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createLineBorder(StyleUtil.PURPLE_LINE));

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                LocalDate clicked = resolveDateAt(e.getX(), e.getY());
                if (clicked != null) {
                    selectedDate = clicked;
                    dateSelectListener.onDateSelected(clicked);
                    repaint();
                }
            }
        });
    }

    public void clearSelectedDate() {
        selectedDate = null;
        repaint();
    }

    public void setYearMonth(int year, int month) {
        this.year = year;
        this.month = month;
        repaint();
    }

    public void setCompactMode(boolean compactMode) {
        this.compactMode = compactMode;
        revalidate();
        repaint();
    }

    @Override
    public Dimension getPreferredSize() {
        int parentWidth = getParent() != null ? getParent().getWidth() - 20 : 780;
        int width = Math.max(320, parentWidth);
        int height = compactMode ? 286 : 340;
        return new Dimension(width, height);
    }

    private LocalDate resolveDateAt(int x, int y) {
        int left = 8;
        int titleH = compactMode ? 38 : 44;
        int weekdayTop = titleH + 8;
        int weekdayH = compactMode ? 24 : 30;
        int gridTop = weekdayTop + weekdayH;

        int availableW = Math.max(7, getWidth() - left - 8);
        int availableH = Math.max(6, getHeight() - gridTop - 10);
        int cols = 7;
        int rows = 6;
        int cw = Math.max(1, availableW / cols);
        int ch = Math.max(1, availableH / rows);
        int gridRight = left + cw * cols;
        int gridBottom = gridTop + ch * rows;

        if (x < left || x >= gridRight || y < gridTop || y >= gridBottom) {
            return null;
        }

        int col = (x - left) / cw;
        int row = (y - gridTop) / ch;
        int idx = row * cols + col;

        YearMonth ym = YearMonth.of(year, month);
        int start = ym.atDay(1).getDayOfWeek().getValue() % 7;
        int day = idx - start + 1;
        if (day < 1 || day > ym.lengthOfMonth()) {
            return null;
        }

        return LocalDate.of(year, month, day);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int w = getWidth();
        int h = getHeight();
        int left = 8;
        int right = w - 8;
        int titleH = compactMode ? 38 : 44;
        int weekdayTop = titleH + 8;
        int weekdayH = compactMode ? 24 : 30;
        int gridTop = weekdayTop + weekdayH;

        int cols = 7;
        int rows = 6;
        int availableW = Math.max(7, right - left);
        int availableH = Math.max(6, h - gridTop - 10);
        int cw = Math.max(1, availableW / cols);
        int ch = Math.max(1, availableH / rows);
        int gridRight = left + cw * cols;
        int gridBottom = gridTop + ch * rows;

        g.setColor(StyleUtil.PURPLE_SOFT);
        g.fillRoundRect(left, 8, Math.max(1, right - left), Math.max(1, titleH - 6), 12, 12);

        g.setFont(new Font("Malgun Gothic", Font.BOLD, compactMode ? 15 : 17));
        String title = String.format("%d년 %02d월", year, month);
        FontMetrics tm = g.getFontMetrics();
        g.setColor(StyleUtil.PURPLE_MAIN);
        g.drawString(title, (w - tm.stringWidth(title)) / 2, compactMode ? 28 : 33);

        g.setFont(new Font("Malgun Gothic", Font.BOLD, compactMode ? 11 : 12));
        FontMetrics wm = g.getFontMetrics();
        for (int col = 0; col < cols; col++) {
            int x = left + col * cw;
            g.setColor(new Color(244, 238, 253));
            g.fillRect(x, weekdayTop, Math.max(1, cw - 1), Math.max(1, weekdayH - 1));
            g.setColor(StyleUtil.PURPLE_LINE);
            g.drawRect(x, weekdayTop, Math.max(1, cw - 1), Math.max(1, weekdayH - 1));
            String t = WEEKDAYS[col];
            g.setColor(StyleUtil.TEXT_DARK);
            g.drawString(t, x + (cw - wm.stringWidth(t)) / 2, weekdayTop + (weekdayH + wm.getAscent()) / 2 - 2);
        }

        g.setColor(StyleUtil.PURPLE_LINE);
        for (int i = 0; i <= cols; i++) {
            int x = left + i * cw;
            g.drawLine(x, gridTop, x, gridBottom - 1);
        }
        for (int i = 0; i <= rows; i++) {
            int y = gridTop + i * ch;
            g.drawLine(left, y, gridRight - 1, y);
        }

        Map<Integer, String> scheduleMap = new HashMap<>();
        Map<Integer, Integer> scheduleCountMap = new HashMap<>();
        Map<Integer, Long> budgetSumMap = new HashMap<>();

        for (ScheduleItem item : scheduleProvider.get()) {
            LocalDate d = item.getDate();
            if (d.getYear() == year && d.getMonthValue() == month) {
                int day = d.getDayOfMonth();
                String text = item.getMemo().isEmpty() ? item.getTitle() : item.getMemo();
                if (!scheduleMap.containsKey(day)) {
                    scheduleMap.put(day, text.length() > 8 ? text.substring(0, 8) + ".." : text);
                }
                scheduleCountMap.put(day, scheduleCountMap.getOrDefault(day, 0) + 1);
            }
        }

        for (BudgetItem item : budgetProvider.get()) {
            LocalDate d = item.getDate();
            if (d.getYear() == year && d.getMonthValue() == month) {
                int day = d.getDayOfMonth();
                long signed = AppState.TYPE_INCOME.equals(item.getType()) ? item.getAmount() : -item.getAmount();
                budgetSumMap.put(day, budgetSumMap.getOrDefault(day, 0L) + signed);
            }
        }

        YearMonth ym = YearMonth.of(year, month);
        int start = ym.atDay(1).getDayOfWeek().getValue() % 7;
        int len = ym.lengthOfMonth();
        LocalDate today = LocalDate.now();

        g.setFont(new Font("Malgun Gothic", Font.PLAIN, compactMode ? 12 : 13));
        FontMetrics dm = g.getFontMetrics();
        Font memoFont = new Font("Malgun Gothic", Font.PLAIN, compactMode ? 10 : 11);

        for (int day = 1; day <= len; day++) {
            int idx = start + day - 1;
            int row = idx / cols;
            int col = idx % cols;
            int x = left + col * cw;
            int y = gridTop + row * ch;

            LocalDate current = LocalDate.of(year, month, day);
            if (today.equals(current)) {
                g.setColor(new Color(235, 226, 252));
                g.fillRect(x + 1, y + 1, Math.max(1, cw - 2), Math.max(1, ch - 2));
            }
            if (selectedDate != null && selectedDate.equals(current)) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(new Color(92, 62, 188));
                g2.setStroke(new BasicStroke(2f));
                g2.drawRect(x + 2, y + 2, Math.max(1, cw - 5), Math.max(1, ch - 5));
            }

            g.setColor(StyleUtil.TEXT_DARK);
            g.drawString(Integer.toString(day), x + 7, y + dm.getAscent() + 6);

            if (scheduleMap.containsKey(day)) {
                int count = scheduleCountMap.get(day);
                if (compactMode) {
                    g.setColor(new Color(107, 76, 196));
                    g.fillOval(x + Math.max(4, cw - 14), y + 6, 7, 7);
                    if (count > 1) {
                        g.setFont(memoFont);
                        g.drawString(Integer.toString(count), x + Math.max(2, cw - 22), y + ch - 8);
                        g.setFont(new Font("Malgun Gothic", Font.PLAIN, compactMode ? 12 : 13));
                    }
                } else {
                    g.setFont(memoFont);
                    g.setColor(new Color(107, 76, 196));
                    String text = scheduleMap.get(day);
                    g.drawString(count > 1 ? text + " +" + (count - 1) : text, x + 7, y + ch - 8);
                    g.setFont(new Font("Malgun Gothic", Font.PLAIN, compactMode ? 12 : 13));
                }
            }

            if (!compactMode && budgetSumMap.containsKey(day)) {
                long sum = budgetSumMap.get(day);
                g.setFont(new Font("Malgun Gothic", Font.BOLD, 10));
                g.setColor(sum >= 0 ? new Color(56, 99, 206) : new Color(210, 68, 90));
                FontMetrics amountMetrics = g.getFontMetrics();
                int maxTextWidth = Math.max(8, cw - 8);
                String text = fitTextToWidth(formatBudgetCompact(sum), amountMetrics, maxTextWidth);
                int tx = x + cw - 4 - amountMetrics.stringWidth(text);
                tx = Math.max(x + 4, tx);
                g.drawString(text, tx, y + 14);
                g.setFont(new Font("Malgun Gothic", Font.PLAIN, compactMode ? 12 : 13));
            }
        }
    }

    private static String formatBudgetCompact(long signedAmount) {
        double v = Math.abs(signedAmount) / 10000.0;
        return BUDGET_DECIMAL.format(v);
    }
    private static String fitTextToWidth(String value, FontMetrics fm, int maxWidth) {
        if (fm.stringWidth(value) <= maxWidth) {
            return value;
        }
        String ellipsis = "..";
        int ellipsisWidth = fm.stringWidth(ellipsis);
        if (ellipsisWidth >= maxWidth) {
            return "";
        }

        int end = value.length();
        while (end > 0 && fm.stringWidth(value.substring(0, end)) + ellipsisWidth > maxWidth) {
            end--;
        }
        if (end <= 0) {
            return "";
        }
        return value.substring(0, end) + ellipsis;
    }
}
