import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JSpinner;

public class FilterUtil {
    private FilterUtil() {}

    public static List<ScheduleItem> filterSchedules(List<ScheduleItem> source, int year, int month, LocalDate selectedDate) {
        List<ScheduleItem> out = new ArrayList<>();
        for (ScheduleItem item : source) {
            if (matches(item.getDate(), year, month, selectedDate)) {
                out.add(item);
            }
        }
        return out;
    }

    public static List<BudgetItem> filterBudgets(List<BudgetItem> source, int year, int month, LocalDate selectedDate) {
        List<BudgetItem> out = new ArrayList<>();
        for (BudgetItem item : source) {
            if (matches(item.getDate(), year, month, selectedDate)) {
                out.add(item);
            }
        }
        return out;
    }

    private static boolean matches(LocalDate date, int year, int month, LocalDate selectedDate) {
        if (selectedDate != null) {
            return date.equals(selectedDate);
        }
        return date.getYear() == year && date.getMonthValue() == month;
    }

    public static Runnable createFilterListener(AppState state, Runnable refreshAll) {
        return () -> {
            state.selectedDate = null;
            if (state.selectedDateLabel != null) {
                state.selectedDateLabel.setText("선택 날짜: 없음");
            }
            if (state.calendarPanel != null) {
                state.calendarPanel.clearSelectedDate();
            }
            refreshAll.run();
        };
    }

    public static void setupFilterListeners(JSpinner yearSpinner, JSpinner monthSpinner, Runnable listener) {
        yearSpinner.addChangeListener(e -> listener.run());
        monthSpinner.addChangeListener(e -> listener.run());
    }
}