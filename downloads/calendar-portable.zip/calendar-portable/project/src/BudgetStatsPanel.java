import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class BudgetStatsPanel extends JPanel {
    private List<BudgetItem> items = new ArrayList<>();
    private String title = "월별 통계";

    public BudgetStatsPanel() {
        setPreferredSize(new Dimension(360, 250));
        setOpaque(true);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleUtil.PURPLE_LINE),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
    }

    public void setData(List<BudgetItem> source, String title) {
        this.items = new ArrayList<>(source);
        this.title = title;

        Map<String, Long> expenseByCategory = new HashMap<>();
        for (BudgetItem item : items) {
            if (!AppState.TYPE_INCOME.equals(item.getType())) {
                expenseByCategory.put(item.getCategory(), expenseByCategory.getOrDefault(item.getCategory(), 0L) + item.getAmount());
            }
        }

        int rows = Math.max(1, expenseByCategory.size());
        int preferredH = Math.max(250, 62 + rows * 18);
        setPreferredSize(new Dimension(360, preferredH));
        revalidate();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        long income = 0;
        long expense = 0;
        Map<String, Long> expenseByCategory = new HashMap<>();

        for (BudgetItem item : items) {
            if (AppState.TYPE_INCOME.equals(item.getType())) {
                income += item.getAmount();
            } else {
                expense += item.getAmount();
                expenseByCategory.put(item.getCategory(), expenseByCategory.getOrDefault(item.getCategory(), 0L) + item.getAmount());
            }
        }

        List<Map.Entry<String, Long>> sorted = new ArrayList<>(expenseByCategory.entrySet());
        sorted.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));

        g2.setFont(StyleUtil.BODY_FONT.deriveFont(Font.BOLD, 13f));
        g2.setColor(StyleUtil.TEXT_DARK);
        g2.drawString(title, 8, 18);

        int contentTop = 28;
        int graphAreaW = Math.max(220, Math.min(350, (int) (w * 0.52)));
        int dividerX = graphAreaW;
        int textX = dividerX + 10;
        int textW = Math.max(90, w - textX - 8);

        int chartTop = contentTop;
        int chartHeight = 96;

        long maxBar = Math.max(1L, Math.max(income, expense));
        int barBaseY = chartTop + chartHeight;
        int barW = 24;
        int barGap = 14;
        int barX1 = 12;
        int barX2 = barX1 + barW + barGap;

        int inH = (int) ((income * chartHeight) / (double) maxBar);
        int outH = (int) ((expense * chartHeight) / (double) maxBar);

        g2.setColor(new Color(83, 128, 228));
        g2.fillRoundRect(barX1, barBaseY - inH, barW, inH, 8, 8);
        g2.setColor(new Color(214, 84, 106));
        g2.fillRoundRect(barX2, barBaseY - outH, barW, outH, 8, 8);

        g2.setColor(StyleUtil.TEXT_SOFT);
        g2.drawLine(8, barBaseY, barX2 + barW + 8, barBaseY);
        g2.setFont(StyleUtil.BODY_FONT.deriveFont(11f));
        g2.drawString("입금", barX1 + 2, barBaseY + 14);
        g2.drawString("출금", barX2 + 2, barBaseY + 14);

        int graphGap = Math.max(8, Math.min(18, (int) (graphAreaW * 0.04)));
        int pieMax = graphAreaW - (barX2 + barW + graphGap + 10);
        int pieD = Math.max(64, Math.min(96, pieMax));
        int pieX = barX2 + barW + graphGap;
        int pieY = chartTop + Math.max(0, (chartHeight - pieD) / 2);

        long totalExpense = Math.max(1L, expense);
        int start = 0;
        Color[] palette = {
            new Color(133, 105, 217), new Color(181, 129, 230), new Color(122, 160, 231),
            new Color(222, 126, 168), new Color(139, 193, 163), new Color(231, 170, 121)
        };

        int idx = 0;
        for (Map.Entry<String, Long> e : sorted) {
            int angle = (int) Math.round((e.getValue() * 360.0) / totalExpense);
            g2.setColor(palette[idx % palette.length]);
            g2.fillArc(pieX, pieY, pieD, pieD, start, angle);
            start += angle;
            idx++;
        }

        g2.setColor(Color.WHITE);
        g2.fillOval(pieX + pieD / 3, pieY + pieD / 3, pieD / 3, pieD / 3);
        g2.setColor(StyleUtil.TEXT_SOFT);
        g2.setFont(StyleUtil.BODY_FONT.deriveFont(Font.BOLD, 11f));
        g2.drawString("지출", pieX + pieD / 2 - 10, pieY + pieD / 2 + 4);

        g2.setColor(new Color(224, 214, 243));
        g2.setStroke(new BasicStroke(1f));
        g2.drawLine(dividerX, contentTop, dividerX, h - 10);

        int listTop = contentTop + 12;
        g2.setColor(StyleUtil.TEXT_DARK);
        g2.setFont(StyleUtil.BODY_FONT.deriveFont(Font.BOLD, 12f));
        g2.drawString("카테고리 순위", textX, listTop);

        int rowY = listTop + 18;
        int amountRight = w - 10;
        int nameMax = Math.max(40, textW - 72);

        g2.setFont(StyleUtil.BODY_FONT.deriveFont(11f));
        FontMetrics fm = g2.getFontMetrics();

        for (int i = 0; i < sorted.size(); i++) {
            Map.Entry<String, Long> e = sorted.get(i);
            String rank = (i + 1) + ". ";
            String name = rank + truncate(e.getKey(), fm, nameMax);
            String amount = Main.formatCurrency(e.getValue());

            g2.setColor(i == 0 ? new Color(126, 95, 220) : StyleUtil.TEXT_SOFT);
            g2.drawString(name, textX, rowY);
            int amountX = amountRight - fm.stringWidth(amount);
            g2.drawString(amount, amountX, rowY);
            rowY += 18;
        }

        g2.setColor(new Color(224, 214, 243));
        g2.setStroke(new BasicStroke(1f));
        g2.drawLine(0, h - 1, w, h - 1);
        g2.dispose();
    }

    private static String truncate(String text, FontMetrics fm, int maxWidth) {
        if (text == null) {
            return "";
        }
        if (fm.stringWidth(text) <= maxWidth) {
            return text;
        }
        String ellipsis = "...";
        int end = text.length();
        while (end > 0 && fm.stringWidth(text.substring(0, end) + ellipsis) > maxWidth) {
            end--;
        }
        return end <= 0 ? ellipsis : text.substring(0, end) + ellipsis;
    }
}