import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class SchedulePanel {
    private SchedulePanel() {}

    public static JPanel create(AppState state, Runnable refreshAll) {
        StyleUtil.CardPanel card = new StyleUtil.CardPanel();
        card.setLayout(new BorderLayout(8, 8));
        card.add(StyleUtil.sectionTitle("일정"), BorderLayout.NORTH);

        state.scheduleModel = new DefaultTableModel(new Object[] {"날짜", "제목", "메모"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = StyleUtil.createStyledTable(state.scheduleModel);

        JTextField dateField = new JTextField(LocalDate.now().toString(), 11);
        state.scheduleDateField = dateField;
        JTextField titleField = new JTextField(14);
        JTextField memoField = new JTextField(22);
        StyleUtil.styleField(dateField);
        StyleUtil.styleField(titleField);
        StyleUtil.styleField(memoField);

        JSpinner filterYear = new JSpinner(state.scheduleYearModel);
        JSpinner filterMonth = new JSpinner(state.scheduleMonthModel);

        Runnable onFilterChanged = FilterUtil.createFilterListener(state, refreshAll);
        FilterUtil.setupFilterListeners(filterYear, filterMonth, onFilterChanged);

        JButton add = new JButton("추가");
        JButton del = new JButton("삭제");
        StyleUtil.styleButton(add, true);
        StyleUtil.styleButton(del, false);

        add.addActionListener(e -> {
            String dateText = dateField.getText().trim();
            String title = titleField.getText().trim();
            if (!Main.isValidDate(dateText)) {
                Main.showError("날짜 형식은 yyyy-MM-dd 입니다.");
                return;
            }
            if (title.isEmpty()) {
                Main.showError("제목을 입력하세요.");
                return;
            }

            state.scheduleItems.add(new ScheduleItem(LocalDate.parse(dateText), title, memoField.getText().trim()));
            titleField.setText("");
            memoField.setText("");
            state.save();
            refreshAll.run();
        });

        del.addActionListener(e -> deleteSelected(state, table, refreshAll));

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    editSelected(state, table, refreshAll);
                }
            }
        });

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;

        addCommonFormFields(form, gc, dateField, titleField, memoField);

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        actionRow.setOpaque(false);
        actionRow.add(add);
        actionRow.add(del);
        gc.gridx = 1; gc.gridy = 3; gc.weightx = 1; form.add(actionRow, gc);

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        filterRow.setOpaque(false);
        filterRow.add(StyleUtil.makeLabel("조회 연도"));
        filterRow.add(filterYear);
        filterRow.add(StyleUtil.makeLabel("조회 월"));
        filterRow.add(filterMonth);
        gc.gridx = 1; gc.gridy = 4; gc.weightx = 1; form.add(filterRow, gc);

        JScrollPane tableScroll = new JScrollPane(table);
        StyleUtil.styleScroll(tableScroll);

        JPanel body = new JPanel(new BorderLayout(8, 8));
        body.setOpaque(false);
        body.add(form, BorderLayout.NORTH);
        body.add(tableScroll, BorderLayout.CENTER);

        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private static void addCommonFormFields(JPanel panel, GridBagConstraints gc,
                                            JTextField dateField, JTextField titleField, JTextField memoField) {
        gc.gridx = 0; gc.gridy = 0; gc.weightx = 0; panel.add(StyleUtil.makeLabel("날짜"), gc);
        gc.gridx = 1; gc.weightx = 1; panel.add(dateField, gc);

        gc.gridx = 0; gc.gridy = 1; gc.weightx = 0; panel.add(StyleUtil.makeLabel("제목"), gc);
        gc.gridx = 1; gc.weightx = 1; panel.add(titleField, gc);

        gc.gridx = 0; gc.gridy = 2; gc.weightx = 0; panel.add(StyleUtil.makeLabel("메모"), gc);
        gc.gridx = 1; gc.weightx = 1; panel.add(memoField, gc);
    }

    private static void deleteSelected(AppState state, JTable table, Runnable refreshAll) {
        int row = table.getSelectedRow();
        if (row < 0 || row >= state.visibleSchedules.size()) {
            Main.showError("삭제할 일정을 선택하세요.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
            table,
            "선택한 일정을 삭제할까요?",
            "삭제 확인",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        state.scheduleItems.remove(state.visibleSchedules.get(row));
        state.save();
        refreshAll.run();
    }

    private static void editSelected(AppState state, JTable table, Runnable refreshAll) {
        int row = table.getSelectedRow();
        if (row < 0 || row >= state.visibleSchedules.size()) {
            return;
        }

        ScheduleItem current = state.visibleSchedules.get(row);

        JTextField dateField = new JTextField(current.getDate().toString(), 12);
        JTextField titleField = new JTextField(current.getTitle(), 16);
        JTextField memoField = new JTextField(current.getMemo(), 20);
        StyleUtil.styleField(dateField);
        StyleUtil.styleField(titleField);
        StyleUtil.styleField(memoField);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;

        addCommonFormFields(panel, gc, dateField, titleField, memoField);

        int result = JOptionPane.showConfirmDialog(
            table,
            panel,
            "일정 수정",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        String dateText = dateField.getText().trim();
        String title = titleField.getText().trim();
        if (!Main.isValidDate(dateText)) {
            Main.showError("날짜 형식은 yyyy-MM-dd 입니다.");
            return;
        }
        if (title.isEmpty()) {
            Main.showError("제목을 입력하세요.");
            return;
        }

        int index = state.scheduleItems.indexOf(current);
        if (index >= 0) {
            state.scheduleItems.set(index, new ScheduleItem(LocalDate.parse(dateText), title, memoField.getText().trim()));
            state.save();
            refreshAll.run();
        }
    }
}