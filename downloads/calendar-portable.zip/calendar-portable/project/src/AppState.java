import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

public class AppState {
    public static final String TYPE_EXPENSE = "출금";
    public static final String TYPE_INCOME = "입금";

    private static final Path DATA_FILE = Paths.get("app-data.json");

    LocalDate selectedDate;

    SpinnerNumberModel calendarYearModel = new SpinnerNumberModel(LocalDate.now().getYear(), 1900, 2100, 1);
    SpinnerNumberModel calendarMonthModel = new SpinnerNumberModel(LocalDate.now().getMonthValue(), 1, 12, 1);
    SpinnerNumberModel scheduleYearModel = new SpinnerNumberModel(LocalDate.now().getYear(), 1900, 2100, 1);
    SpinnerNumberModel scheduleMonthModel = new SpinnerNumberModel(LocalDate.now().getMonthValue(), 1, 12, 1);
    SpinnerNumberModel budgetYearModel = new SpinnerNumberModel(LocalDate.now().getYear(), 1900, 2100, 1);
    SpinnerNumberModel budgetMonthModel = new SpinnerNumberModel(LocalDate.now().getMonthValue(), 1, 12, 1);

    final List<ScheduleItem> scheduleItems = new ArrayList<>();
    final List<BudgetItem> budgetItems = new ArrayList<>();
    List<ScheduleItem> visibleSchedules = new ArrayList<>();
    List<BudgetItem> visibleBudgets = new ArrayList<>();

    DefaultTableModel scheduleModel;
    DefaultTableModel budgetModel;

    JLabel selectedDateLabel;
    JLabel totalInLabel;
    JLabel totalOutLabel;
    JLabel totalNetLabel;
    JTextField scheduleDateField;
    JTextField budgetDateField;

    CalendarPanel calendarPanel;
    JPanel budgetWrap;
    JPanel budgetCategoryPanel;
    JList<String> budgetCategoryList;
    JScrollPane budgetCategoryScroll;
    BudgetStatsPanel budgetStatsPanel;

    boolean compactMode;

    public void load() {
        scheduleItems.clear();
        budgetItems.clear();

        if (!Files.exists(DATA_FILE)) {
            return;
        }

        try {
            String json = Files.readString(DATA_FILE, StandardCharsets.UTF_8);

            String scheduleArray = JsonStore.extractArray(json, "schedules");
            for (String obj : JsonStore.splitObjects(scheduleArray)) {
                String date = JsonStore.extractString(obj, "date");
                String title = JsonStore.extractString(obj, "title");
                String memo = JsonStore.extractString(obj, "memo");
                if (!date.isEmpty()) {
                    scheduleItems.add(new ScheduleItem(LocalDate.parse(date), title, memo));
                }
            }

            String budgetArray = JsonStore.extractArray(json, "budgets");
            for (String obj : JsonStore.splitObjects(budgetArray)) {
                String date = JsonStore.extractString(obj, "date");
                String type = JsonStore.extractString(obj, "type");
                String category = JsonStore.extractString(obj, "category");
                long amount = JsonStore.extractLong(obj, "amount", 0L);
                String memo = JsonStore.extractString(obj, "memo");
                String photoPath = JsonStore.extractString(obj, "photoPath");
                if (!date.isEmpty()) {
                    budgetItems.add(new BudgetItem(LocalDate.parse(date), normalizeType(type), category, amount, memo, photoPath));
                }
            }
        } catch (Exception ex) {
            scheduleItems.clear();
            budgetItems.clear();
        }
    }

    public void save() {
        try {
            Files.writeString(DATA_FILE, toJson(), StandardCharsets.UTF_8);
        } catch (IOException ignored) {
        }
    }

    public void saveBackup() {
        String name = "backup_" + LocalDate.now().format(DateTimeFormatter.ISO_DATE) + ".json";
        Path backup = Paths.get(name);
        try {
            Files.writeString(backup, toJson(), StandardCharsets.UTF_8);
        } catch (IOException ignored) {
        }
    }

    private static String normalizeType(String type) {
        if (TYPE_INCOME.equals(type)) {
            return TYPE_INCOME;
        }
        if (TYPE_EXPENSE.equals(type)) {
            return TYPE_EXPENSE;
        }

        String t = type == null ? "" : type.toLowerCase();
        if (t.contains("income") || t.equals("in")) {
            return TYPE_INCOME;
        }
        return TYPE_EXPENSE;
    }

    private String toJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"schedules\": [\n");
        for (int i = 0; i < scheduleItems.size(); i++) {
            ScheduleItem item = scheduleItems.get(i);
            sb.append("    {\"date\":\"").append(JsonStore.escape(item.getDate().toString())).append("\",")
              .append("\"title\":\"").append(JsonStore.escape(item.getTitle())).append("\",")
              .append("\"memo\":\"").append(JsonStore.escape(item.getMemo())).append("\"}");
            if (i < scheduleItems.size() - 1) {
                sb.append(",");
            }
            sb.append("\n");
        }
        sb.append("  ],\n");
        sb.append("  \"budgets\": [\n");
        for (int i = 0; i < budgetItems.size(); i++) {
            BudgetItem item = budgetItems.get(i);
            sb.append("    {\"date\":\"").append(JsonStore.escape(item.getDate().toString())).append("\",")
              .append("\"type\":\"").append(JsonStore.escape(item.getType())).append("\",")
              .append("\"category\":\"").append(JsonStore.escape(item.getCategory())).append("\",")
              .append("\"amount\":").append(item.getAmount()).append(",")
              .append("\"memo\":\"").append(JsonStore.escape(item.getMemo())).append("\",")
              .append("\"photoPath\":\"").append(JsonStore.escape(item.getPhotoPath())).append("\"}");
            if (i < budgetItems.size() - 1) {
                sb.append(",");
            }
            sb.append("\n");
        }
        sb.append("  ]\n");
        sb.append("}\n");
        return sb.toString();
    }

    private static final class JsonStore {
        private JsonStore() {}

        static String escape(String value) {
            if (value == null) {
                return "";
            }
            return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
        }

        static String unescape(String value) {
            return value
                .replace("\\n", "\n")
                .replace("\\r", "\r")
                .replace("\\\"", "\"")
                .replace("\\\\", "\\");
        }

        static String extractArray(String json, String key) {
            int keyIdx = json.indexOf("\"" + key + "\"");
            if (keyIdx < 0) {
                return "[]";
            }
            int start = json.indexOf('[', keyIdx);
            if (start < 0) {
                return "[]";
            }
            int depth = 0;
            boolean inString = false;
            for (int i = start; i < json.length(); i++) {
                char c = json.charAt(i);
                if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) {
                    inString = !inString;
                }
                if (inString) {
                    continue;
                }
                if (c == '[') {
                    depth++;
                } else if (c == ']') {
                    depth--;
                    if (depth == 0) {
                        return json.substring(start, i + 1);
                    }
                }
            }
            return "[]";
        }

        static List<String> splitObjects(String arrayJson) {
            List<String> out = new ArrayList<>();
            int depth = 0;
            int start = -1;
            boolean inString = false;
            for (int i = 0; i < arrayJson.length(); i++) {
                char c = arrayJson.charAt(i);
                if (c == '"' && (i == 0 || arrayJson.charAt(i - 1) != '\\')) {
                    inString = !inString;
                }
                if (inString) {
                    continue;
                }
                if (c == '{') {
                    if (depth == 0) {
                        start = i;
                    }
                    depth++;
                } else if (c == '}') {
                    depth--;
                    if (depth == 0 && start >= 0) {
                        out.add(arrayJson.substring(start, i + 1));
                    }
                }
            }
            return out;
        }

        static String extractString(String objJson, String key) {
            int keyIdx = objJson.indexOf("\"" + key + "\"");
            if (keyIdx < 0) {
                return "";
            }
            int colon = objJson.indexOf(':', keyIdx);
            int firstQuote = objJson.indexOf('"', colon + 1);
            if (firstQuote < 0) {
                return "";
            }
            StringBuilder sb = new StringBuilder();
            for (int i = firstQuote + 1; i < objJson.length(); i++) {
                char c = objJson.charAt(i);
                if (c == '"' && objJson.charAt(i - 1) != '\\') {
                    return unescape(sb.toString());
                }
                sb.append(c);
            }
            return "";
        }

        static long extractLong(String objJson, String key, long defaultValue) {
            int keyIdx = objJson.indexOf("\"" + key + "\"");
            if (keyIdx < 0) {
                return defaultValue;
            }
            int colon = objJson.indexOf(':', keyIdx);
            if (colon < 0) {
                return defaultValue;
            }

            int i = colon + 1;
            while (i < objJson.length() && Character.isWhitespace(objJson.charAt(i))) {
                i++;
            }
            int end = i;
            while (end < objJson.length() && "0123456789-".indexOf(objJson.charAt(end)) >= 0) {
                end++;
            }
            String raw = objJson.substring(i, end).trim();
            if (raw.isEmpty()) {
                return defaultValue;
            }
            try {
                return Long.parseLong(raw);
            } catch (NumberFormatException ex) {
                return defaultValue;
            }
        }
    }
}