import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class StyleUtil {
    public static final Color PURPLE_MAIN = new Color(92, 64, 176);
    public static final Color PURPLE_SOFT = new Color(236, 229, 250);
    public static final Color PURPLE_LINE = new Color(194, 176, 232);
    public static final Color TEXT_DARK = new Color(34, 27, 56);
    public static final Color TEXT_SOFT = new Color(74, 63, 112);

    public static final Font TITLE_FONT = new Font("Malgun Gothic", Font.BOLD, 24);
    public static final Font SECTION_FONT = new Font("Malgun Gothic", Font.BOLD, 16);
    public static final Font BODY_FONT = new Font("Malgun Gothic", Font.PLAIN, 13);

    private StyleUtil() {}

    public static JPanel sectionTitle(String title) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel.setOpaque(false);
        JLabel label = new JLabel(title);
        label.setFont(SECTION_FONT);
        label.setForeground(PURPLE_MAIN);
        panel.add(label);
        return panel;
    }

    public static JLabel makeLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(BODY_FONT);
        label.setForeground(TEXT_DARK);
        return label;
    }

    public static JLabel summaryLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(BODY_FONT.deriveFont(Font.BOLD));
        label.setForeground(PURPLE_MAIN);
        label.setOpaque(true);
        label.setBackground(new Color(241, 236, 252));
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PURPLE_LINE),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return label;
    }

    public static void styleField(JTextField field) {
        field.setFont(BODY_FONT);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PURPLE_LINE),
            BorderFactory.createEmptyBorder(5, 7, 5, 7)
        ));
    }

    public static void styleButton(JButton button, boolean primary) {
        button.setFont(BODY_FONT.deriveFont(Font.BOLD));
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(170, 152, 220), 1, true),
            BorderFactory.createEmptyBorder(7, 12, 7, 12)
        ));
        button.setBackground(new Color(214, 203, 242));
        button.setForeground(TEXT_DARK);
    }

    public static void styleScroll(JScrollPane scroll) {
        scroll.setBorder(BorderFactory.createLineBorder(PURPLE_LINE));
        scroll.getViewport().setBackground(Color.WHITE);
    }

    public static JTable createStyledTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setFont(BODY_FONT);
        table.setRowHeight(25);
        table.getTableHeader().setFont(BODY_FONT.deriveFont(Font.BOLD));
        table.getTableHeader().setBackground(PURPLE_SOFT);
        table.getTableHeader().setForeground(TEXT_DARK);
        table.setGridColor(PURPLE_LINE);
        table.setSelectionBackground(new Color(183, 165, 232));
        table.setSelectionForeground(TEXT_DARK);

        DefaultTableCellRenderer strip = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object value, boolean selected, boolean focus, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, value, selected, focus, row, col);
                if (!selected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(246, 242, 253));
                    c.setForeground(TEXT_DARK);
                }
                return c;
            }
        };

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(strip);
        }
        return table;
    }

    public static void styleBudgetMemoRenderer(JTable table) {
        TableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object value, boolean selected, boolean focus, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, value, selected, focus, row, col);
                if (!selected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(246, 242, 253));
                    int modelRow = t.convertRowIndexToModel(row);
                    String type = String.valueOf(t.getModel().getValueAt(modelRow, 1));
                    if (col == 3) { // 금액 컬럼만 색상 적용
                        if (AppState.TYPE_INCOME.equals(type)) {
                            c.setForeground(new Color(56, 99, 206));
                        } else {
                            c.setForeground(new Color(210, 68, 90));
                        }
                    } else {
                        c.setForeground(TEXT_DARK);
                    }
                } else {
                    c.setForeground(TEXT_DARK);
                }
                return c;
            }
        };

        for (int i = 0; i < table.getColumnCount(); i++) {
            if (i != 5) { // Skip photo column
                table.getColumnModel().getColumn(i).setCellRenderer(renderer);
            }
        }
    }

    public static JPanel createFormPanel() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        return form;
    }

    public static GridBagConstraints createFormConstraints() {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        return gc;
    }

    public static void addFormField(JPanel panel, GridBagConstraints gc, String labelText, Component field, int y) {
        gc.gridx = 0; gc.gridy = y; gc.weightx = 0; panel.add(makeLabel(labelText), gc);
        gc.gridx = 1; gc.weightx = 1; panel.add(field, gc);
    }

    public static void addActionRow(JPanel panel, GridBagConstraints gc, Component actionRow, int y) {
        gc.gridx = 1; gc.gridy = y; gc.weightx = 1; panel.add(actionRow, gc);
    }

    public static void addFilterRow(JPanel panel, GridBagConstraints gc, Component filterRow, int y) {
        gc.gridx = 1; gc.gridy = y; gc.weightx = 1; panel.add(filterRow, gc);
    }

    public static JPanel createFilterRow(Component... components) {
        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        filterRow.setOpaque(false);
        for (Component c : components) {
            filterRow.add(c);
        }
        return filterRow;
    }

    public static JScrollPane createTableScroll(JTable table) {
        JScrollPane tableScroll = new JScrollPane(table);
        styleScroll(tableScroll);
        return tableScroll;
    }

    public static class CardPanel extends JPanel {
        public CardPanel() {
            setOpaque(false);
            setAlignmentX(Component.LEFT_ALIGNMENT);
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 2400));
            setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(190, 175, 230, 120));
            g2.fillRoundRect(3, 4, getWidth() - 7, getHeight() - 6, 20, 20);
            g2.setColor(Color.WHITE);
            g2.fillRoundRect(0, 0, getWidth() - 7, getHeight() - 7, 20, 20);
            g2.setColor(PURPLE_LINE);
            g2.setStroke(new BasicStroke(1.3f));
            g2.drawRoundRect(0, 0, getWidth() - 7, getHeight() - 7, 20, 20);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp = new GradientPaint(0, 0, new Color(245, 241, 253), 0, getHeight(), new Color(232, 224, 248));
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();
        }
    }
}