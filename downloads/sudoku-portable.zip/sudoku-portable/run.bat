@echo off
chcp 65001 > nul
setlocal
set "PROJECT_DIR=%~dp0project"
cd /d "%PROJECT_DIR%"
where java > nul 2> nul
if errorlevel 1 (
    echo Java was not found. Install a JDK and try again.
    pause
    exit /b 1
)
where javac > nul 2> nul
if errorlevel 1 (
    echo javac was not found. A JDK is required.
    pause
    exit /b 1
)
if not exist out mkdir out
powershell -NoProfile -ExecutionPolicy Bypass -Command "$files = @(Get-ChildItem -Recurse -Path 'src' -Filter '*.java' | ForEach-Object { $_.FullName }); if ($files.Count -eq 0) { Write-Host 'No Java files found.'; exit 2 }; & javac -encoding UTF-8 -d out $files"
if errorlevel 1 (
    echo Compile failed.
    pause
    exit /b 1
)
java -cp "out;src;assets;images;data" Main %*
pause
