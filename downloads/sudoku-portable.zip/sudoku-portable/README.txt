yampf926 portable package

Project: 스도쿠

1. Extract this ZIP.
2. Run run.bat on Windows.
3. Java projects require a JDK. Dohwa also requires Node.js and Maven wrapper dependencies.
